
// Jobs API Route
const express = require("express");
const router = express.Router();

// Sample job data (later replace with database)
const jobs = [
  { id: 1, title: "Software Engineer", location: "Kingston, Jamaica" },
  { id: 2, title: "Hotel Manager", location: "Nassau, Bahamas" },
  { id: 3, title: "Marketing Specialist", location: "Bridgetown, Barbados" },
];

// Get all jobs
router.get("/", (req, res) => {
  res.json(jobs);
});

// Get single job
router.get("/:id", (req, res) => {
  const job = jobs.find((j) => j.id === parseInt(req.params.id));
  if (job) res.json(job);
  else res.status(404).json({ message: "Job not found" });
});

module.exports = router;
