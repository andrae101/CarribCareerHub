
// Apply API Route
const express = require("express");
const router = express.Router();

// Handle job application submission
router.post("/", (req, res) => {
  const { name, email, jobId, coverLetter } = req.body;

  if (!name || !email || !jobId) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  // In a real app, you’d save to DB or send email here
  res.json({ message: "Application submitted successfully!", data: req.body });
});

module.exports = router;
