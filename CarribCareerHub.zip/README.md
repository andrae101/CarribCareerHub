# CarribCareerHub

A fast, static job board for the Caribbean — like CaribbeanJobs, but snappier and open-source.

## Quick start
1. Download the ZIP and unzip.
2. Push to GitHub: create a repo called **CarribCareerHub** and upload all files.
3. Enable GitHub Pages (Settings → Pages → Source: **Deploy from a branch**, Branch: **main**/**docs**).
4. Your site will be live at `https://<your-username>.github.io/CarribCareerHub/`.

## Local edits
- Job data: `data/jobs.json`
- Blog posts: `data/posts.json`
- Branding/colors: `styles.css` and `assets/logo.svg`

## Demo auth
- Candidate and Employer sign-in is **localStorage-only** for demo. Do not use real passwords.
- Employers can post jobs in **this browser** and they show up in the Jobs list (on this device).

## Roadmap
- Real backend (Supabase/Firebase), email alerts, paid/featured listings, search indexing, RSS, i18n.
