import { $, $$ } from './app.js';
async function load(){
  const res = await fetch('data/posts.json'); const posts = await res.json();
  $('#posts').innerHTML = posts.map(p=>`<li class="card"><a href="post.html?slug=${encodeURIComponent(p.slug)}"><h3>${p.title}</h3></a>
    <p class="muted">${p.date}</p><p>${p.excerpt}</p></li>`).join('');
}
load();
