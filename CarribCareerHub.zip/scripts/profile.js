import { $, store } from './app.js';
const u = store.get('cch_user', null);
$('#welcome').textContent = u ? `Signed in as ${u.email}` : 'Not signed in.';
function renderSaved(){
  const saved = new Set(store.get('cch_saved', []));
  const list = $('#saved-jobs');
  fetch('data/jobs.json').then(r=>r.json()).then(js=>{
    const mine = store.get('cch_my_jobs', []);
    const all = [...mine, ...js];
    list.innerHTML = [...saved].map(id=>{
      const j = all.find(x=>String(x.id)===String(id)); if(!j) return '';
      return `<li class="job-item"><a href="job.html?id=${encodeURIComponent(j.id)}"><h3>${j.title}</h3></a>
      <div class="meta">${j.company} • ${j.location}</div></li>`;
    }).join('') || '<p class="muted">No saved jobs.</p>';
  })
}
renderSaved();
// saved searches + alerts
const searches = new Set(store.get('cch_saved_searches', []));
$('#saved-searches').innerHTML = [...searches].map(s=>`<li>${s}</li>`).join('') || '<p class="muted">No saved searches.</p>';
const alerts = store.get('cch_alerts', []);
$('#alerts').innerHTML = alerts.map(a=>`<li>Alert: ${a.q||''} in ${a.loc||'Anywhere'}</li>`).join('') || '<p class="muted">No alerts yet.</p>';
$('#alert-form')?.addEventListener('submit', e=>{ e.preventDefault();
  const a={ q: $('#aq').value, loc: $('#aloc').value }; const arr=store.get('cch_alerts', []); arr.push(a); store.set('cch_alerts', arr);
  $('#alerts').innerHTML += `<li>Alert: ${a.q||''} in ${a.loc||'Anywhere'}</li>`; e.target.reset();
});
