import { $, $$, store } from './app.js';
const PAGE_SIZE = 5;
let all = []; let page = 1; let filtered = [];

async function load(){
  const res = await fetch('data/jobs.json'); all = await res.json();
  // overlay employer-created jobs from localStorage
  const added = store.get('cch_my_jobs', []); all = [...added, ...all];
  render();
  syncFromURL();
}
function syncFromURL(){
  const params = new URLSearchParams(location.search);
  $('#f-q').value = params.get('q') || '';
  $('#f-location').value = params.get('location') || '';
  $('#f-category').value = params.get('category') || '';
  $('#f-type').value = params.get('type') || '';
  $('#f-min').value = params.get('min') || '';
  $('#f-max').value = params.get('max') || '';
  filter();
}
function filter(){
  const q = $('#f-q').value.toLowerCase().trim();
  const loc = $('#f-location').value.toLowerCase().trim();
  const cat = $('#f-category').value;
  const type = $('#f-type').value;
  const min = parseInt($('#f-min').value || '0', 10);
  const max = parseInt($('#f-max').value || '0', 10);
  const sort = $('#f-sort').value || 'new';
  filtered = all.filter(j=>{
    const hay = (j.title+' '+j.company+' '+j.location+' '+(j.desc||'')).toLowerCase();
    const okQ = !q || hay.includes(q);
    const okLoc = !loc || j.location.toLowerCase().includes(loc);
    const okCat = !cat || j.category===cat;
    const okType = !type || j.type===type;
    const okMin = !min || (j.min||0) >= min;
    const okMax = !max || (j.max||0) <= max || (!j.max && (j.min||0)<=max);
    return okQ && okLoc && okCat && okType && okMin && okMax;
  });
  filtered.sort((a,b)=>{
    if(sort==='salaryHigh') return (b.max||b.min||0)-(a.max||a.min||0);
    if(sort==='salaryLow') return (a.min||0)-(b.min||0);
    if(sort==='relevance') return 0;
    return new Date(b.posted)-new Date(a.posted);
  });
  page = 1; render();
}
function render(){
  const list = $('#jobs-list'); const count = $('#results-count');
  const saved = new Set(store.get('cch_saved', []));
  if(!filtered.length) filtered = all;
  const start = (page-1)*PAGE_SIZE; const pageItems = filtered.slice(start, start+PAGE_SIZE);
  list.innerHTML = pageItems.map(j=>`<li class="job-item">
    <a href="job.html?id=${encodeURIComponent(j.id)}"><h3>${j.title}</h3></a>
    <div class="meta"><span>${j.company}</span><span>•</span><span>${j.location}</span>
      <span class="badge">${j.type}</span><span class="badge">${j.category}</span>
      ${(j.min||j.max)?`<span class="badge">USD ${j.min?.toLocaleString()} - ${j.max?.toLocaleString()}</span>`:''}
    </div>
    <div class="controls">
      <button data-id="${j.id}" class="btn save">${saved.has(j.id)?'Saved ✓':'Save'}</button>
      <button data-id="${j.id}" class="btn outline apply">Quick apply</button>
    </div>
  </li>`).join('');
  count.textContent = `${filtered.length} job${filtered.length!==1?'s':''} found`;
  // pagination
  $('#page-indicator').textContent = `Page ${page} of ${Math.max(1, Math.ceil(filtered.length/PAGE_SIZE))}`;
  $('#prev').disabled = page<=1; $('#next').disabled = start+PAGE_SIZE>=filtered.length;
  // bind buttons
  $$('.save').forEach(b=>b.addEventListener('click', ()=>toggleSave(b.dataset.id, b)));
  $$('.apply').forEach(b=>b.addEventListener('click', ()=>openApply(b.dataset.id)));
}
function toggleSave(id, btn){
  const saved = new Set(store.get('cch_saved', []));
  if(saved.has(id)) saved.delete(id); else saved.add(id);
  store.set('cch_saved', [...saved]);
  btn.textContent = saved.has(id)?'Saved ✓':'Save';
  renderSaved();
}
function renderSaved(){
  const saved = new Set(store.get('cch_saved', []));
  const items = filtered.length?filtered:all;
  const list = $('#saved-list');
  list.innerHTML = [...saved].map(id=>{
    const j = items.find(x=>x.id===id); if(!j) return '';
    return `<li><a href="job.html?id=${encodeURIComponent(j.id)}">${j.title}</a></li>`
  }).join('') || '<li class="muted">No saved jobs yet.</li>';
}
function openApply(id){
  const modal = $('#apply-modal'); modal.hidden = false;
  $('.modal-close').onclick = ()=>modal.hidden=true;
  $('#apply-form').onsubmit = (e)=>{
    e.preventDefault();
    const form = new FormData(e.target);
    $('.form-status').textContent = 'Application sent (demo)!';
    setTimeout(()=>{ modal.hidden = true; $('.form-status').textContent='' }, 1200);
  };
}
$('#filters')?.addEventListener('submit', e=>{e.preventDefault(); filter()});
$('#clear-filters')?.addEventListener('click', ()=>{ location.href='jobs.html' });
$('#prev')?.addEventListener('click', ()=>{ page--; render() });
$('#next')?.addEventListener('click', ()=>{ page++; render() });
load().then(renderSaved);
