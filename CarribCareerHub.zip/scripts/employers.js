import { $, store } from './app.js';
const gate = $('#employer-gate'); const area = $('#employer-area');
const u = store.get('cch_user', null);
if(u?.role==='employer'){ gate.hidden = true; area.hidden = false; renderMine() }
const form = $('#post-form');
form?.addEventListener('submit', (e)=>{
  e.preventDefault();
  const id = String(Date.now());
  const j = {
    id, title: $('#p-title').value, company: $('#p-company').value,
    location: $('#p-location').value, type: $('#p-type').value, category: $('#p-category').value,
    min: parseInt($('#p-min').value||'0',10), max: parseInt($('#p-max').value||'0',10),
    posted: new Date().toISOString().slice(0,10), desc: $('#p-desc').value,
    req: ($('#p-req').value||'').split(',').map(s=>s.trim()).filter(Boolean)
  };
  const mine = store.get('cch_my_jobs', []); mine.unshift(j); store.set('cch_my_jobs', mine);
  $('.form-status').textContent = 'Saved! It will appear in the jobs list on this browser.';
  form.reset(); renderMine();
});
function renderMine(){
  const mine = store.get('cch_my_jobs', []);
  $('#my-jobs').innerHTML = mine.map(j=>`<li class="job-item">
  <h3>${j.title}</h3><div class="meta">${j.company} • ${j.location} • ${j.type} • ${j.category}</div>
  <div class="controls"><a class="btn outline" href="job.html?id=${encodeURIComponent(j.id)}">View</a>
  <button data-id="${j.id}" class="btn outline del">Delete</button></div></li>`).join('') || '<p class="muted">No postings yet.</p>';
  $('#my-jobs')?.querySelectorAll('.del').forEach(b=>b.addEventListener('click', ()=>{
    const mine = store.get('cch_my_jobs', []).filter(x=>x.id!==b.dataset.id); store.set('cch_my_jobs', mine); renderMine();
  }));
}
