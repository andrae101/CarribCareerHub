import { $ } from './app.js';
function md(s){ return s.replace(/^# (.*)$/gm,'<h1>$1</h1>').replace(/^## (.*)$/gm,'<h2>$1</h2>').replace(/^\- (.*)$/gm,'<li>$1</li>').replace(/\n\n/g,'</p><p>').replace(/^/,'<p>').concat('</p>') }
async function load(){
  const res = await fetch('data/posts.json'); const posts = await res.json();
  const slug = new URLSearchParams(location.search).get('slug');
  const p = posts.find(x=>x.slug===slug) || posts[0];
  $('#post').innerHTML = `<h1>${p.title}</h1><p class="muted">${p.date}</p>${md(p.content)}`;
}
load();
