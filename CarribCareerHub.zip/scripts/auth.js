import { $, store } from './app.js';
const q = new URLSearchParams(location.search); const presetRole = q.get('role');
if(presetRole) $('#role').value = presetRole;
$('#signin').addEventListener('click', auth);
$('#signup').addEventListener('click', auth);
function auth(e){
  const email = $('#email').value.trim(); const role = $('#role').value;
  if(!email){ $('.form-status').textContent = 'Enter email'; return }
  const user = { email, role };
  store.set('cch_user', user);
  $('.form-status').textContent = 'Signed in!';
  setTimeout(()=>location.href = role==='employer' ? 'employers.html' : 'profile.html', 600);
}
