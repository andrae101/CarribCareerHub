import { $, store } from './app.js';
async function load(){
  const params = new URLSearchParams(location.search); const id = params.get('id');
  const res = await fetch('data/jobs.json'); let jobs = await res.json();
  jobs = [...store.get('cch_my_jobs', []), ...jobs];
  const j = jobs.find(x=>String(x.id)===String(id)) || jobs[0];
  const el = $('#job-detail');
  el.innerHTML = `
    <div class="meta"><a href="jobs.html">← Back to jobs</a></div>
    <h1>${j.title}</h1>
    <p class="muted">${j.company} • ${j.location} • <span class="badge">${j.type}</span> <span class="badge">${j.category}</span></p>
    ${(j.min||j.max)?`<p><strong>Salary:</strong> USD ${j.min?.toLocaleString()} - ${j.max?.toLocaleString()}</p>`:''}
    <h2>About the role</h2><p>${j.desc||''}</p>
    ${j.req?.length?'<h3>Requirements</h3><ul>'+j.req.map(r=>`<li>${r}</li>`).join('')+'</ul>':''}
    <div class="controls"><button class="btn apply">Quick apply</button> <button class="btn outline save">Save</button></div>
  `;
  el.querySelector('.apply').addEventListener('click', ()=>location.href='jobs.html');
  el.querySelector('.save').addEventListener('click', ()=>{
    const saved = new Set(store.get('cch_saved', []));
    saved.add(j.id); store.set('cch_saved', [...saved]); alert('Saved!');
  });
}
load();
