// global UI + helpers
const $ = (s, d=document)=>d.querySelector(s);
const $$ = (s, d=document)=>[...d.querySelectorAll(s)];
const store = {
  get(k, fallback){ try{ return JSON.parse(localStorage.getItem(k)) ?? fallback }catch{ return fallback } },
  set(k, v){ localStorage.setItem(k, JSON.stringify(v)) }
};
// header year
const y = document.getElementById('year'); if(y) y.textContent = new Date().getFullYear();
// mobile nav
const toggle = $('.nav-toggle'); const menu = $('#nav-menu');
if(toggle && menu){ toggle.addEventListener('click', ()=>{ const open = menu.classList.toggle('open'); toggle.setAttribute('aria-expanded', open) }) }
// auth link
const user = store.get('cch_user', null);
const authLink = $('#auth-link');
if(authLink){
  if(user){ authLink.textContent = 'My profile'; authLink.href = 'profile.html'; }
  else{ authLink.textContent = 'Sign in'; authLink.href = 'login.html'; }
}
export { $, $$, store };
